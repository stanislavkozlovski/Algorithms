﻿using System;
using System.Collections.Generic;
using System.Linq;

class Snakes
{
    static int snakesCount = 0;
    static List<string> moves = new List<string>();
    static bool[,] matrix;
    static bool printed = false;
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        matrix = new bool[n, n];
        GenSnake(n, "S");
        Console.WriteLine("Snakes count = {0}", snakesCount);
    }
    static void GenSnake(int n, string dir,int row = 0, int col = 0,int index = 1)
    {
        if(index > n)
        {
            Console.WriteLine(string.Join("", moves));
            snakesCount++;
            printed = true;
        }
        else
        {
            if (matrix[row, col] == false)
            {
                matrix[row, col] = true;
                moves.Add(dir);

                if (dir != "L" && col + 1 < n && !printed) GenSnake(n, "R", row, col + 1, index + 1);
                if (dir != "U" && row + 1 < n && !printed) GenSnake(n, "D", row + 1, col, index + 1);
                if (dir != "R" && col - 1 >= 0 && !printed) GenSnake(n, "L", row, col - 1, index + 1);
                if (dir != "D" && row - 1 >= 0 && !printed) GenSnake(n, "U", row - 1, col, index + 1);

                printed = false;
                matrix[row, col] = false;
                moves.RemoveAt(moves.Count() - 1);
            }

            else return;

        }
    }
}

